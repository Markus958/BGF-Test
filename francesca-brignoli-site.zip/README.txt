Website-Dateien für Upload auf GitHub Pages.
Ersetzen Sie images/portrait.jpg durch Ihr echtes Porträt.
